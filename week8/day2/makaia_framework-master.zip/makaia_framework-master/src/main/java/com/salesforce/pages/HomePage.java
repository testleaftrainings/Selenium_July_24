package com.salesforce.pages;

public class HomePage {

}
