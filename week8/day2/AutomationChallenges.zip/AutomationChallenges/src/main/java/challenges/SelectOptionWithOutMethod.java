package challenges;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class SelectOptionWithOutMethod {

	public static void main(String[] args) {

		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.get("https://www.telerik.com/contact");
		
		//if option tag have meaning attribute and value 
		//directly write with attribute value
		driver.findElement(By.id("account-activation")).click();

		driver.findElement(By.id("ui-for-angular")).click();
		
		
	}

}
