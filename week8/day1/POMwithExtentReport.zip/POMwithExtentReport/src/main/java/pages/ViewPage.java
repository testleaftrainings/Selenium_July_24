 package pages;

import base.BaseClass;

public class ViewPage extends BaseClass {

}
