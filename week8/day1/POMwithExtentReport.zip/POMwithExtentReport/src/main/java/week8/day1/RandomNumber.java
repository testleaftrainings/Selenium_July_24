package week8.day1;

public class RandomNumber {

public static void main(String[] args) {
	
	int random = (int)(Math.random()*99999);
	System.out.println(random);
	
	//./SnapShots/img"+random+"/png
	//img45678
	//img08756
	//img23456
}
	
}
