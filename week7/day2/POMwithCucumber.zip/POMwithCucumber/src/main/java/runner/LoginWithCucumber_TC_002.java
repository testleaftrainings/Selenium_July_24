package runner;

import org.testng.annotations.DataProvider;

import base.BaseClass;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = "src/main/java/features/LoginPage.feature",
glue="pages",
monochrome = true,
publish = true
)


public class LoginWithCucumber_TC_002 extends BaseClass{

	  @DataProvider(parallel = true)
	    public Object[][] scenarios() {
	        return super.scenarios();
	    }
}
//super keyword -access parent class data