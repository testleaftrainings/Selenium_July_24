package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginPage extends BaseClass {

	
	@When("Enter the Username as")
	public LoginPage enterUserName() {
		getDriver().findElement(By.id("username")).sendKeys(p.getProperty("username"));
		return this;
	}
	@When("Enter the Password as")
	public LoginPage enterPassword() {
		getDriver().findElement(By.id("password")).sendKeys(p.getProperty("password"));
		
		return this;

	}
	
	@When("Click on LoginButton")
	public HomePage clickonLoginButtom() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
	
		
		return new HomePage();
		
		
	}
	
	@Then("Verify login is Successful")
	public void verifyPage() {
		String title = getDriver().getTitle();
		
		if(title.contains("TestLeaf")) {
			System.out.println("login is successful");
		}else {
			System.out.println("login is not successful");
		}
	}

}
