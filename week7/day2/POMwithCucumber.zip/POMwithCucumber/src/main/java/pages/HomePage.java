package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.When;

public class HomePage extends BaseClass{

	
	@When("Click on Crmsfa")
	public MyHomePage clickOnCrmsfa() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
		
		return new MyHomePage();

	}
	
	public LoginPage clickOnLogout() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		
		return new LoginPage();

	}
	
}
