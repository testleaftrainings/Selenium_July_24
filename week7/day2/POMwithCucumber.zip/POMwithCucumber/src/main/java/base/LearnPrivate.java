package base;

public class LearnPrivate {

	public static void main(String[] args) {

Encapsulation e=new Encapsulation();
e.setName("Dilip");

System.out.println(e.getName());
	}

}
