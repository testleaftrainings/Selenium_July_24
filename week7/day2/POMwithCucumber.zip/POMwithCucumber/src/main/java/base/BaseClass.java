package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ExcelIntegration;


public class BaseClass extends AbstractTestNGCucumberTests {
	
	//properties variable should have common value to all the pages or testcase
//so we need add  static keyword
	public static Properties p;
	
	
	//step 1 
	private static final ThreadLocal<RemoteWebDriver> tlDriver=new ThreadLocal<RemoteWebDriver>();
	
	//set driver value
	public void setDriver() {
		tlDriver.set(new ChromeDriver());
	}
	
	//get driver value pass all pages
	public RemoteWebDriver getDriver() {
		return tlDriver.get();
	}
	//change driver variable name into getDriver()
	public String filepath;
	@BeforeMethod
	public void preCondition() throws IOException {
		
		FileInputStream f=new FileInputStream("src/main/resources/French.properties");
	//declare Properties as globally and make it static
	   p=new Properties();
		
	   p.load(f);
		
		
	setDriver();
	getDriver().manage().window().maximize();
	getDriver().get("http://leaftaps.com/opentaps/control/main");
	getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
}	
	@AfterMethod
	public void postCondition() {
		getDriver().close();
	}
	
	@DataProvider(name="fetchData" ,indices = {1})
	public String[][] setValue() throws IOException{
		
		String[][] readValue = ExcelIntegration.readValue(filepath);
		return readValue;
	}
	

}
