package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ReadValuesFromPropertieFile {

	public static void main(String[] args) throws IOException {

//step1 set path of properties file
		
		FileInputStream f=new FileInputStream("src/main/resources/French.properties");
	
	//step 2 create object for Properties class
		Properties p=new Properties();
		
		//step 3 load all values for step 1 to step 2
		p.load(f);
		
		
		//step 4 print any values ,use getproperty(key name) to get value
		String property = p.getProperty("MyHomePage.Leads");
		System.out.println(property);
	
	
	}

}
