package base;

public class Encapsulation {

	private String name;

	//read value of the private fields
	public String getName() {
		return name;
	}

	//modify the values of the private fields
	public void setName(String name) {
		this.name = name;
	}
	
}
